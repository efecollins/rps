var rock = document.querySelector('.rock');

var paper = document.querySelector('.paper');

var scissors = document.querySelector('.scissors');

var gameBG = document.querySelector('.game-icon_bg');

var pickText = document.querySelector('.game-text');

var computer = document.querySelector('.computer');


var computerSelectPosition = Math.floor(Math.random() * 3);

var computerSelectIcon = document.querySelectorAll('.border');

rock.addEventListener("click", pickRock);
paper.addEventListener("click", pickPaper);
scissors.addEventListener("click", pickScissors);

function pickRock() {
    rock.classList.add('game-item_move');
    rock.style.marginTop = "10px";
    rock.style.top = "0";
    scissors.classList.add('picked');
    gameBG.classList.add('picked');
    pickText.firstElementChild.classList.add('pickText');
    paper.classList.add('picked');
    setTimeout(function() {
        pickText.lastElementChild.classList.add('pickText');
    }, 1000);

    setTimeout(function() {
        computer.classList.add('pickText');
    }, 1300); 
    
    setTimeout(function() {
        if (computerSelectPosition === 0) {
            computerSelectIcon[0].classList.add('display_computer-selection');
        } else if (computerSelectPosition === 1) {
            computerSelectIcon[1].classList.add('display_computer-selection');
        } else {
            computerSelectIcon[2].classList.add('display_computer-selection');
        }

        computer.classList.remove('pickText');
    }, 3000);
}

function pickPaper() {
    rock.classList.add('picked');
    scissors.classList.add('picked');
    gameBG.classList.add('picked');
    pickText.firstElementChild.classList.add('pickText');
    paper.classList.add('game-item_move');
    setTimeout(function() {
        pickText.lastElementChild.classList.add('pickText');
    }, 1000);

    setTimeout(function() {
        computer.classList.add('pickText');
    }, 1300);

    setTimeout(function() {
        if (computerSelectPosition === 0) {
            computerSelectIcon[0].classList.add('display_computer-selection');
        } else if (computerSelectPosition === 1) {
            computerSelectIcon[1].classList.add('display_computer-selection');
        } else {
            computerSelectIcon[2].classList.add('display_computer-selection');
        }

        computer.classList.remove('pickText');
    }, 3000);
}

function pickScissors() {
    rock.classList.add('picked');
    paper.classList.add('picked');
    gameBG.classList.add('picked');
    pickText.firstElementChild.classList.add('pickText');
    scissors.classList.add('game-item_move');
    setTimeout(function() {
        pickText.lastElementChild.classList.add('pickText');
    }, 1000);

    setTimeout(function() {
        computer.classList.add('pickText');
    }, 1300);

    setTimeout(function() {
        if (computerSelectPosition === 0) {
            computerSelectIcon[0].classList.add('display_computer-selection');
        } else if (computerSelectPosition === 1) {
            computerSelectIcon[1].classList.add('display_computer-selection');
        } else {
            computerSelectIcon[2].classList.add('display_computer-selection');
        }

        computer.classList.remove('pickText');
    }, 3000);
}

// To select the one chosen by the computer
